package main;

import shop.Artikel;
import shop.Warenkorb;

public class Main
{
    public static void main(String[] args)
    {
        Warenkorb wkorb = new Warenkorb();

        wkorb.add(new Artikel("lel", 1243));
        wkorb.add(new Artikel("lel", 1243));
        wkorb.add(new Artikel("lel", 1243));
        wkorb.add(new Artikel("lel", 1243));
        wkorb.add(new Artikel("lel", 1243));


        wkorb.remove(new Artikel("lel", 1243));

        System.out.println(wkorb.getAnzahl());
    }
}
